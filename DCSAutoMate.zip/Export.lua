dofile(lfs.writedir()..[[Scripts\DCSAutoMateExport.lua]])
